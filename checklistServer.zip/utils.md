# DATABASE = mongodb+srv://Mayank:Mayank12@legal-crm.wsfzr5m.mongodb.net/Legal-CRM?retryWrites=true&w=majority
